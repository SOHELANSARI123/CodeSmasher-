import axios from 'axios';
import { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [todosData, setTodosData] = useState([]);
  const [userData, setUserData] = useState([]);



  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/todos').then((response) => {
      console.log(response.data.slice(0, 10));
      setTodosData(response.data.slice(0, 10))
    })
  },[]);

  const getUserData = (id) => {
    axios.get(`https://jsonplaceholder.typicode.com/users/${id}`).then((response) => {
      console.log(response.data);
      setUserData(response.data)
    })
  }
  const filteredData = (e)=> {
    const searchedData = todosData.filter((data)=> data.title === e.target.value);
    console.log(searchedData);

  }
  return (
    <div className="App">
      <div className="navbar">
        <div className="left">
          <label>Todos</label>
          <div className="search">
            <input type="text" name="search" className="round" onKeyUp={(e)=>filteredData(e)}/>
          </div>
          
          <table id="todos">
            <tr>
              <th>Todo ID</th>
              <th>Title</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
            {
              todosData.map((todo) => (
                <tr>
                  <td>{todo.id}</td>
                  <td>{todo.title}</td>
                  <td>{todo.status ? 'completed': 'Not completed'}</td>
                  <td><button id="btn" onClick={()=>getUserData(todo.id)}>View User</button></td>
                </tr>
              ))
            }
          </table>
        </div>
      </div>

<div className="right">

                <ul>
                  <li>ID   :{userData.id}</li>
                  <li>NAME :{userData.name}</li>
                  <li>EMAIL:{userData.email}</li>
                </ul>
        

</div>

    </div>
  );
}

export default App;
